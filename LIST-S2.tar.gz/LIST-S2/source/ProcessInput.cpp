/*
 * ProcessInput.cpp
 *
 *  Created on: Jun 21, 2019
 *      Author: nmalhis
 */

#include "ProcessInput.h"

namespace std {
short STP::ST_max = 0;
int STP::Taxa_ID = 0;

void ProcessInput::align(vector <string> &inSeqV, vector <string> &psaV, int dbCount) {
  string line;
  vector <string> basic_cmd_V;

  for (unsigned k = 0; k < inSeqV.size(); k++) {
    string basic_cmd("blastp -outfmt 0 -evalue 0.1 -gapopen 11 -gapextend 2 ");
    basic_cmd.append("-num_descriptions 50000  -num_alignments 50000 -num_threads ");
    if (k == 0) {
	basic_cmd.append(thrds0);
    } else {
	basic_cmd.append(thrds);
    }
    basic_cmd.append(" -query ");
    basic_cmd.append(inSeqV.at(k));
    basic_cmd.append(" -db ");
    basic_cmd.append(_ROOT_DATA);
    basic_cmd.append(_DB_PATH);
    basic_cmd_V.push_back(basic_cmd);
  }

  for (int i = 0; i < dbCount; i++) {
    cout << '.';
    cout.flush();
    int ret;
    string str_part;
    stringstream ss;
    ss << i;
    ss >> str_part;
    for (unsigned k = 0; k < inSeqV.size(); k++) {
	string b_cmd(basic_cmd_V.at(k));
	b_cmd.append(str_part);
	b_cmd.append("/DB ");
	string cmd(b_cmd);
	cmd.append(" -out ");
	cmd.append(psaV.at(k));
	// cmd.append("_");
	cmd.append(str_part);
	cmd.append(".psa");
	ret = system(cmd.c_str());
    }
  }
  cout << endl;
  cout.flush();
}

void ProcessInput::lpsa_to_stp(string inFile, string outFile) {
  _lpsa_file.assign(inFile);
  _stp_file.assign(outFile);
  _load_lpsaVec();
  _process_lpsaVec_b();
  return;
}

void ProcessInput::lpsa_to_stp_O(string inFile, string outFile) {
  _lpsa_file.assign(inFile);
  _stp_file.assign(outFile);
  _load_lpsaVec();
  _process_lpsaVec_O();
  return;
}

void ProcessInput::_load_lpsaVec() {
  string lpsa_line;
  lpsaVec.clear();
  STP::ST_max = 0;
  ifstream fin;
  fin.open(_lpsa_file.c_str());
  if (!fin.is_open()) {
    cerr << "Error in Alignment::_2_lpsa_to_stp, can not open "
	   << _lpsa_file << endl;
    return;
  }
  getline(fin, lpsa_line);
  _query.set(lpsa_line);
  getline(fin, lpsa_line);
  while (!fin.eof()) {
    _subject.set(lpsa_line);
    // filter sequences longer than 20000 to identity greater than 0.45
    if (_subject.seq.size() < 20000 || _subject.identity > 0.45) {
	lpsaVec.push_back(_subject);
    }
    getline(fin, lpsa_line);
  }
  fin.close();
}

void ProcessInput::_process_lpsaVec_b() {
  stpVec.clear();
  if (_query.taxa_id == 0) {
    cerr << "ERROR in ProcessInput::_process_lpsaVec()\t_query.taxa_id == 0" << endl;
    exit(1);
  }
  STP::Taxa_ID = _query.taxa_id;
  STP::ST_max = _query.ST_max = TTree.fillLineage(_query.taxa_id); // !!!!!!!!!!!!!!!!!!
  _query.ST = TTree.get_shared_taxa(_query.taxa_id);
  // cerr << _query.ac << "\tTID:\t" << STP::Taxa_ID << "\tST_max:\t" << STP::ST_max << endl;
  for (unsigned i = 0; i < lpsaVec.size(); i++) {
    lpsaVec.at(i).ST = TTree.get_shared_taxa(lpsaVec.at(i).taxa_id);
  }
  
  vector<vector<vector<int> > > licVec3 (20, vector<vector<int> >(STP::ST_max + 1, vector<int>(STP_RADIOS * 2 + 2, 0)));
  for (unsigned pos = 0; pos < _query.seq.size(); pos++) {
    for (short iAi = 0; iAi < 20; iAi++) {
	for (short iSt = 0; iSt < STP::ST_max + 1; iSt++) {
	  for (short iLi = 0; iLi < STP_RADIOS * 2 + 2; iLi++) {
	    licVec3[iAi][iSt][iLi] = 0;
	  }
	}
    }
    STP stp;
    short refi = _get_aa_idx(_query.seq.at(pos));
    if (refi == 20) {
	stpVec.push_back(stp);
	continue;
    }
    for (unsigned i = 0; i < lpsaVec.size(); i++) { // depth
	short ai = _get_aa_idx(lpsaVec.at(i).seq.at(pos));
	short LI = _get_LI(pos, i);
	short sti = lpsaVec.at(i).ST;
	if (ai < 20 && ai >= 0) {
	  if (sti > 0)
	    licVec3[ai][sti][LI]++;
	  // start filter
	  if (lpsaVec.at(i).identity >= STP_IDEN_MIN
	      && (lpsaVec.at(i).matches >= STP_MATCH_MIN
		  || (lpsaVec.size() <= 25
		      && lpsaVec.at(i).matches
		      >= (lpsaVec.size() * 75) / 100))) {
	    if (LI > STP_RADIOS)
	      stp.depth++;
	    if (LI >= STP_RADIOS) { // ---------------------- STP
	      if (refi != ai) {
		stp.stp_count[sti]++;
		if (stp.stp_identity[sti] < LI) {
		  stp.stp_identity[sti] = LI;
		}
	      }
	    }
	    // ----------------------------------------------- PVM
	    if (LI > stp.a_lIdentity[ai]
		|| (LI == stp.a_lIdentity[ai]
		    && lpsaVec.at(i).SI > stp.a_sIdentity[ai])
		|| (LI == stp.a_lIdentity[ai]
		    && lpsaVec.at(i).SI == stp.a_sIdentity[ai]
		    && lpsaVec.at(i).ST > stp.a_staxa[ai])) {
	      // --------------------------------------------------------
	      stp.a_lIdentity[ai] = LI;
	      stp.a_sIdentity[ai] = lpsaVec.at(i).SI;
	      stp.a_staxa[ai] = lpsaVec.at(i).ST;
	      // --------------------------------------------------------
	    }
	  }
	}
    } // for i=0

    for (short iAi = 0; iAi < 20; iAi++) {
	for (short iLi = 0; iLi < STP_RADIOS * 2 + 2; iLi++) {
	  for (short iSt = STP::ST_max - 1; iSt >= 0; iSt--) {
	    licVec3[iAi][iSt][iLi] += licVec3[iAi][iSt + 1][iLi];
	  }
	}
    }

    for (short iAi = 0; iAi < 20; iAi++) {
	short iLi = stp.a_lIdentity[iAi];
	short iST = stp.a_staxa[iAi];

	if (iLi > 2 && iST > 0) {
	  stp.a_count[iAi] = licVec3[iAi][iST][iLi];
	  if (stp.depth > _HIGH_DEPTH) {
	    short x = iST;
	    while (licVec3[iAi][x][iLi] < 2 && x > 0) {
	      x--;
	      stp.a_count[iAi] = licVec3[iAi][x][iLi];
	      stp.a_staxa[iAi] = x;
	    }
	  }
	} else {
	  stp.a_count[iAi] = 0;
	}
    }

    short ai_max = 0;
    for (short ai = 0; ai < 20; ai++) {
	if (stp.a_lIdentity[ai] > stp.a_lIdentity[ai_max]
	    || (stp.a_lIdentity[ai] == stp.a_lIdentity[ai_max]
		&& stp.a_staxa[ai] > stp.a_staxa[ai_max])) {
	  ai_max = ai;
	}
	if (stp.a_lIdentity[ai_max] > 0) {
	  stp.ai_max = ai_max;
	} else {
	  stp.ai_max = -1;
	}
    }
    stpVec.push_back(stp);
  }
  // ------------------------------------------------------------ Output
  ofstream fout;
  fout.open(_stp_file.c_str());
  fout << "Taxa/ST_max:\t" << STP::Taxa_ID << "\t" << STP::ST_max << endl;
  for (unsigned pos = 0; pos < stpVec.size(); pos++) {
    stpVec.at(pos).loci = pos + 1;
    stpVec.at(pos).raa = _query.seq.at(pos);
    stpVec.at(pos).ri = _get_aa_idx(_query.seq.at(pos));
    fout << stpVec.at(pos).to_string() << endl;
  }
  fout.close();
}

void ProcessInput::_process_lpsaVec() {
  int liCount[20][32][STP_RADIOS * 2 + 2];
  stpVec.clear();
  if (_query.taxa_id == 0) {
    cerr << "ERROR in ProcessInput::_process_lpsaVec()\t_query.taxa_id == 0"
	   << endl;
    exit(0);
  }
  TTree.fillLineage(_query.taxa_id); // !!!!!!!!!!!!!!!!!!
  _query.ST = TTree.get_shared_taxa(_query.taxa_id);
  for (unsigned i = 0; i < lpsaVec.size(); i++) {
    lpsaVec.at(i).ST = TTree.get_shared_taxa(lpsaVec.at(i).taxa_id);
  }
  for (unsigned pos = 0; pos < _query.seq.size(); pos++) { // =============================== POS
    for (short iAi = 0; iAi < 20; iAi++) {
	for (short iSt = 0; iSt < 32; iSt++) {
	  for (short iLi = 0; iLi < STP_RADIOS * 2 + 2; iLi++) {
	    liCount[iAi][iSt][iLi] = 0;
	  }
	}
    }
    STP stp;
    short refi = _get_aa_idx(_query.seq.at(pos));
    if (refi == 20) {
	stpVec.push_back(stp);
	continue;
    }
    for (unsigned i = 0; i < lpsaVec.size(); i++) { // depth
	short ai = _get_aa_idx(lpsaVec.at(i).seq.at(pos));
	short LI = _get_LI(pos, i);
	short sti = lpsaVec.at(i).ST;
	if (ai < 20 && ai >= 0) {
	  if (sti > 0)
	    liCount[ai][sti][LI]++;
	  // start filter
	  if (lpsaVec.at(i).identity >= STP_IDEN_MIN
	      && (lpsaVec.at(i).matches >= STP_MATCH_MIN
		  || (lpsaVec.size() <= 25
		      && lpsaVec.at(i).matches
		      >= (lpsaVec.size() * 75) / 100))) {
	    if (LI > STP_RADIOS) // ------(5)--- new added (+1)
	      stp.depth++;

	    if (LI >= STP_RADIOS) { // + _4_rpmo ------------ STP
	      // stp.a_count[ai]++;
	      if (refi != ai) {
		stp.stp_count[sti]++;
		if (stp.stp_identity[sti] < LI) {
		  stp.stp_identity[sti] = LI;
		}
	      }
	    }
	    // ----------------------------------------------- PVM
	    if (LI > stp.a_lIdentity[ai]
		|| (LI == stp.a_lIdentity[ai]
		    && lpsaVec.at(i).SI > stp.a_sIdentity[ai])
		|| (LI == stp.a_lIdentity[ai]
		    && lpsaVec.at(i).SI == stp.a_sIdentity[ai]
		    && lpsaVec.at(i).ST > stp.a_staxa[ai])) {
	      // --------------------------------------------------------
	      stp.a_lIdentity[ai] = LI;
	      stp.a_sIdentity[ai] = lpsaVec.at(i).SI;
	      stp.a_staxa[ai] = lpsaVec.at(i).ST;
	      // --------------------------------------------------------
	    }
	  }
	}
    } // for i=0

    for (short iAi = 0; iAi < 20; iAi++) {
	for (short iLi = 0; iLi < STP_RADIOS * 2 + 2; iLi++) {
	  for (short iSt = 30; iSt >= 0; iSt--) {
	    liCount[iAi][iSt][iLi] += liCount[iAi][iSt + 1][iLi];
	  }
	}
    }

    for (short iAi = 0; iAi < 20; iAi++) {
	short iLi = stp.a_lIdentity[iAi];
	short iST = stp.a_staxa[iAi];

	if (iLi > 2 && iST > 0) {
	  stp.a_count[iAi] = liCount[iAi][iST][iLi];
	  if (stp.depth > _HIGH_DEPTH) {
	    short x = iST;
	    while (liCount[iAi][x][iLi] < 2 && x > 0) {
	      x--;
	      stp.a_count[iAi] = liCount[iAi][x][iLi];
	      stp.a_staxa[iAi] = x;
	    }
	  }
	} else {
	  stp.a_count[iAi] = 0;
	}
    }

    short ai_max = 0;
    for (short ai = 0; ai < 20; ai++) {
	if (stp.a_lIdentity[ai] > stp.a_lIdentity[ai_max]
	    || (stp.a_lIdentity[ai] == stp.a_lIdentity[ai_max]
		&& stp.a_staxa[ai] > stp.a_staxa[ai_max])) {
	  ai_max = ai;
	}
	if (stp.a_lIdentity[ai_max] > 0) {
	  stp.ai_max = ai_max;
	} else {
	  stp.ai_max = -1;
	}
    }
    stpVec.push_back(stp);
  }

  // ------------------------------------------------------------ Output
  ofstream fout;
  fout.open(_stp_file.c_str());
  for (unsigned pos = 0; pos < stpVec.size(); pos++) {
    stpVec.at(pos).loci = pos + 1;
    stpVec.at(pos).raa = _query.seq.at(pos);
    stpVec.at(pos).ri = _get_aa_idx(_query.seq.at(pos));
    fout << stpVec.at(pos).to_string() << endl;
  }
  fout.close();
}

void ProcessInput::_process_lpsaVec_O() {
  // int liCount[20][32][STP_RADIOS * 2 + 2];
  stpVec.clear();
  if (_query.taxa_id == 0) {
    cerr << "ERROR in ProcessInput::_process_lpsaVec()\t_query.taxa_id == 0"
	   << endl;
    exit(0);
  }
  TTree.fillLineage(_query.taxa_id); // !!!!!!!!!!!!!!!!!!
  _query.ST = TTree.get_shared_taxa(_query.taxa_id);
  for (unsigned i = 0; i < lpsaVec.size(); i++) {
    lpsaVec.at(i).ST = TTree.get_shared_taxa(lpsaVec.at(i).taxa_id);
  }
  for (unsigned pos = 0; pos < _query.seq.size(); pos++) { // =============================== POS
    STP stp;
    short refi = _get_aa_idx(_query.seq.at(pos));
    if (refi == 20) {
	stpVec.push_back(stp);
	continue;
    }
    for (unsigned i = 0; i < lpsaVec.size(); i++) { // depth
	short ai = _get_aa_idx(lpsaVec.at(i).seq.at(pos));
	short LI = _get_LI(pos, i);
	short sti = lpsaVec.at(i).ST;
	if (ai < 20 && ai >= 0) {
	  if (sti > 0) {
	    stp.a_count[ai]++;
	  }
	  // start filter
	  if (lpsaVec.at(i).identity >= STP_IDEN_MIN
	      && (lpsaVec.at(i).matches >= STP_MATCH_MIN
		  || (lpsaVec.size() <= 25
		      && lpsaVec.at(i).matches
		      >= (lpsaVec.size() * 75) / 100))) {
	    if (LI > STP_RADIOS) // ------(5)--- new added (+1)
	      stp.depth++;

	    if (LI >= STP_RADIOS) { // + _4_rpmo ------------ STP
	      if (refi != ai) {
		stp.stp_count[sti]++;
		if (stp.stp_identity[sti] < LI) {
		  stp.stp_identity[sti] = LI;
		}
	      }
	    }
	    // ----------------------------------------------- PVM
	    if (LI > stp.a_lIdentity[ai]
		|| (LI == stp.a_lIdentity[ai]
		    && lpsaVec.at(i).SI > stp.a_sIdentity[ai])
		|| (LI == stp.a_lIdentity[ai]
		    && lpsaVec.at(i).SI == stp.a_sIdentity[ai]
		    && sti > stp.a_staxa[ai])) {
	      // --------------------------------------------------------
	      stp.a_lIdentity[ai] = LI;
	      stp.a_sIdentity[ai] = lpsaVec.at(i).SI;
	      stp.a_staxa[ai] = sti;
	      // --------------------------------------------------------
	    }
	  }
	}
    } // for i=0

    short ai_max = 0;
    for (short ai = 0; ai < 20; ai++) {
	if (stp.a_lIdentity[ai] > stp.a_lIdentity[ai_max]
	    || (stp.a_lIdentity[ai] == stp.a_lIdentity[ai_max]
		&& stp.a_staxa[ai] > stp.a_staxa[ai_max])) {
	  ai_max = ai;
	}
	if (stp.a_lIdentity[ai_max] > 0) {
	  stp.ai_max = ai_max;
	} else {
	  stp.ai_max = -1;
	}
    }
    stpVec.push_back(stp);
  }

  // ------------------------------------------------------------ Output
  ofstream fout;
  fout.open(_stp_file.c_str());
  for (unsigned pos = 0; pos < stpVec.size(); pos++) {
    stpVec.at(pos).loci = pos + 1;
    stpVec.at(pos).raa = _query.seq.at(pos);
    stpVec.at(pos).ri = _get_aa_idx(_query.seq.at(pos));
    fout << stpVec.at(pos).to_string() << endl;
  }
  fout.close();
}

int ProcessInput::_get_LI(int loci, int pidx) {
  short ret = 0;
  int sst;
  int sed;
  if (_query.seq.size() <= (2 * STP_RADIOS + 1)) {
    sst = 0;
    sed = _query.seq.size();
  } else {
    sst = loci - STP_RADIOS;
    if (sst < 0) {
	sst = 0;
    }
    sed = loci + STP_RADIOS + 1; // OK
    if (sed > lpsaVec.at(pidx).seq.size()) {
	sed = lpsaVec.at(pidx).seq.size();
    }
  }
  for (int i = sst; i < sed; i++) {
    if (i != loci
	  && _query.seq.at(i) == toupper(lpsaVec.at(pidx).seq.at(i))) {
	ret++;
    }
  }
  if (loci == _query.first || loci == _query.last) {
    ret += ret / 2;
  }
  return ret;
}

void ProcessInput::clean() {
  lpsaVec.clear();
  stpVec.clear();
  _edge_score_min = EDGE_SCORE_MIN_;
  _gap_edg_size = GAP_EDG_SIZE_;
  _sec_match_min = SEC_MATCH_MIN_;
  _sec_iden_min = SEC_IDEN_MIN_;
  querySectionSeq.assign("");
  matchSectionSeq.assign("");
  subjectSectionSeq.assign("");
  _lpsa_file.assign("");
  _stp_file.assign("");
  querySection_Start = 0;
  querySection_End = 0;
  sbjctSection_Start = 0;
  sbjctSection_End = 0;
  subject_Size = 0;
}

void ProcessInput::psa_to_lpsa(string inSeq, string psaID, string lpsa, int tid, int dbCount) {
  _load_querySeq(inSeq);
  _query.taxa_id = tid;

  _lpsa_file.assign(lpsa);
  _3_lpsaout.open(_lpsa_file.c_str());
  _3_lpsaout << _query.head << '\t' << _query.taxa_id << '\t'
	       << _query.seq.size();
  _3_lpsaout << "\t0\t" << _query.seq << endl;

  for (int i = 0; i < dbCount; i++) {
    string str_part;
    stringstream ss;
    ss << i;
    ss >> str_part;
    string inFile_psa(psaID);
    inFile_psa.append(str_part);
    inFile_psa.append(".psa");
    _fin0.open(inFile_psa.c_str());
    if (_fin0.is_open()) {
      _process_alignment();
      _fin0.close();
    }
  }
  _3_lpsaout.close();
  return;
}

  int ProcessInput::_get_TID(string fasta_file) {
    ifstream fin;
    int ret = 0;
    string line;
    fin.open(fasta_file.c_str());
    if (fin.is_open()) {
      string st_xo;
      getline(fin, line);
      while(!fin.eof() && line.size() < 2) {
	 getline(fin, line);
      }
      if (line.size() > 2) {
	if (line.at(0) == '>') {
	  if (line.find("OX=") != string::npos) {
	    stringstream ss(line);
	    while(!ss.eof()) {
	      ss >> st_xo;
	      if (st_xo.find("OX=") == 0) {
		st_xo.at(2) = ' ';
		stringstream ss2(st_xo);
		ss2 >> st_xo;
		ss2 >> ret;
		fin.close();
		if (ret > 0 && ret < TTree.taxaVec.size()) {
		  if (TTree.taxaVec.at(ret) == 0) {
		    cerr << "X Removed:\t" << fasta_file << " OX=" << ret << ", not a valid OX" << endl;
		    return -1;
		  } else if (TTree.taxaVec.at(ret) == -100) {
		    cerr << "X Removed:\t" << fasta_file << " OX=" << ret << ", a virus OX" << endl;
		    return -1;		    
		  }
		}
		return ret;
	      }
	    }
	  }
	  fin.close();
	  return 0;
	}
      }
      fin.close();
    } else {
      return -2;
    }
    return ret;
  }
    
  int ProcessInput::_get_TID(string psaID, int dbCount) {
    ifstream fin;
    int taxa, ret = -1;
    float bscore, max_bs;
    string line, sid;
    max_bs = 0;
    for (int i = 0; i < dbCount; i++) {
      string str_part;
      stringstream ss;
      ss << i;
      ss >> str_part;
      string inFile_psa(psaID);
      inFile_psa.append(str_part);
      inFile_psa.append(".psa");
      fin.open(inFile_psa.c_str());
      if (fin.is_open()) {
	getline(fin, line);
	while (!fin.eof()) {
	  if (line.find("(Bits)") < line.size()) {
	    getline(fin, line);
	    break;
	  }
	  getline(fin, line);
	}
	getline(fin, line);
	while (!fin.eof()) {
	  if (line.size() < 5) {
	    break;
	  }
	  stringstream ss(line);
	  ss >> sid;
	  ss >> taxa;
	  ss >> bscore;
	  if (bscore > max_bs) {
	    max_bs = bscore;
	    ret = taxa;
	  } if (bscore == max_bs && taxa == 9606) {
		    ret = taxa;
	  }
	  getline(fin, line);
	}
	fin.close();
    }
  }
  return ret;
}

void ProcessInput::_process_alignment() {
  string line;
  int qSize;
  getline(_fin0, line);
  while (!_fin0.eof()) {
    if (line.find("Sequences producing significant alignments:")
	  < line.size()) {
	getline(_fin0, line); // blank
	break;
    } else if (line.find("Query=") < line.size()) {
	while (!(line.find("Length=") < line.size()))
	  getline(_fin0, line);
	stringstream ss;
	ss << line.substr(7);
	ss >> qSize;
    }
    getline(_fin0, line);
  }
  getline(_fin0, line);
  while (!_fin0.eof() && line.size() > 5) {
    getline(_fin0, line); // Skip the initial list
  }
  getline(_fin0, line);
  int blnk_count = 0;
  querySection_Start = -1;
  _subject.ac.assign("");
  while (!_fin0.eof()) {
    if (line.size() > 0) {
	if (line.at(0) == '>') {
	  if (blnk_count == 2) {
	    if (_subject.ac.size() > 0) {
	      _process_section();
	    } else {
	      _subject.clear();
	    }
	  }
	  blnk_count = 0;
	  if (_subject.ac.size() > 3) {
	    _subject.clear();
	  }
	  _new_subject(line);
	} else if (line.find("Identities") < line.size()) {
	  if (_subject.ac.size() > 0) {
	    _new_section(line);
	  }
	} else if (blnk_count == 2) {
	  if (_subject.ac.size() > 0) {
	    _process_section();
	  }
	} else if (line.find("Query") == 0) {
	  if (_subject.ac.size() > 0) {
	    _in_section(line);
	  } else {
	    getline(_fin0, line);
	    getline(_fin0, line);
	  }
	}
	blnk_count = 0;
    } else {
	blnk_count++;
    }
    getline(_fin0, line);
  }
}

void ProcessInput::_new_subject(string &line) {
  stringstream ss1(line.substr(1));
  ss1 >> _subject.ac;
  ss1 >> _subject.taxa_id;
  if (_subject.taxa_id > 0 && _subject.taxa_id < TTree.taxaVec.size()) {
    if (TTree.taxaVec.at( _subject.taxa_id) <= 0) {
      _subject.ac.assign("");
    }
  } else {
    _subject.ac.assign("");
  }
  while (!(line.find("Length=") < line.size()))
    getline(_fin0, line);
  stringstream ss2;
  ss2 << line.substr(7);
  ss2 >> subject_Size;
}

void ProcessInput::_new_section(string& line) {
  querySection_Start = -1;
  querySection_End = -1;
  sbjctSection_Start = -1;
  sbjctSection_End = -1;
  querySectionSeq.assign("");
  subjectSectionSeq.assign("");
  matchSectionSeq.assign("");
}

void ProcessInput::_in_section(string& line) {
  string tmps;
  int matchi;
  stringstream ss0(line);
  ss0 >> tmps;
  if (querySection_Start < 0)
    ss0 >> querySection_Start;
  else
    ss0 >> tmps;
  ss0 >> tmps;
  matchi = line.find(tmps, 5);
  querySectionSeq.append(tmps);
  ss0 >> querySection_End;

  getline(_fin0, line);
  matchSectionSeq.append(line.substr(matchi));

  getline(_fin0, line);
  stringstream ss2(line);
  ss2 >> tmps;
  if (sbjctSection_Start < 0)
    ss2 >> sbjctSection_Start;
  else
    ss2 >> tmps;
  ss2 >> tmps;
  subjectSectionSeq.append(tmps);
  ss2 >> sbjctSection_End;
  sbjctSection_End++;
}

void ProcessInput::_process_section() {
  if (querySection_Start >= 0) {
    if ((querySectionSeq.size() != matchSectionSeq.size())
	  || (querySectionSeq.size() != subjectSectionSeq.size())) {
	cerr << "Size Error: subAC: " << _subject.ac << "\t"
	     << sbjctSection_Start;
	cerr << "\t" << sbjctSection_End << endl;
	cerr << querySectionSeq << "| query section size: "
	     << querySectionSeq.size() << endl;
	cerr << matchSectionSeq << "| match section size: "
	     << matchSectionSeq.size() << endl;
	cerr << subjectSectionSeq << "| subject section size: "
	     << subjectSectionSeq.size() << endl;
	exit(0);
    }
    int gapps_inQuery = 0;
    string lpsa_seq(string(_query.seq.size(), '.'));
    string match_seq(string(_query.seq.size(), '.'));
    vector<short> mask(_query.seq.size(), 0);
    int local = 0;
    for (int i = querySection_Start - 1;
	   (i - gapps_inQuery) < (int) _query.seq.size(); i++) {
	if (local >= (int) subjectSectionSeq.size()) {
	  break;
	}
	if (subjectSectionSeq.at(local) == '-') {
	  mask.at(i - gapps_inQuery) = 1;
	} else if (querySectionSeq.at(local) == '-') {
	  mask.at(i - gapps_inQuery) = 2;
	  gapps_inQuery++;
	} else {
	  lpsa_seq.at(i - gapps_inQuery) = subjectSectionSeq.at(local);
	  match_seq.at(i - gapps_inQuery) = matchSectionSeq.at(local);
	}
	local++;
    }

    // ------------------------------------ _gap_edg_size (tolower)
    int lc_count = 0;
    for (unsigned k = 0; k < mask.size(); k++) {
	if (mask.at(k) > 0)
	  lc_count = _gap_edg_size;
	if (lc_count > 0 && isalpha(lpsa_seq.at(k))) {
	  lpsa_seq.at(k) = tolower(lpsa_seq.at(k));
	  lc_count--;
	}
    }
    lc_count = 0;
    for (int k = mask.size() - 1; k >= 0; k--) {
	if (lc_count > 0 && isalpha(lpsa_seq.at(k))) {
	  lpsa_seq.at(k) = tolower(lpsa_seq.at(k));
	  lc_count--;
	}
	if (mask.at(k) > 0)
	  lc_count = _gap_edg_size;
    }
    // ----------------------------------------- _edge_score_min
    if (querySection_End > (int) mask.size()) {
	cerr << "Fatal ERROD, ";
	cerr << "querySection_End:\t" << querySection_End << " : "
	     << mask.size() << endl;
	exit(1);
    }
    int pass = 0;
    int edgeStart = querySection_Start - 1;
    int edgeEnd = querySection_End;
    int score = 0;
    for (int k = querySection_Start - 1; k < querySection_End - 5; k++) {
	if (match_seq.at(k) == '+') {
	  score += 1;
	} else if (match_seq.at(k) == toupper(lpsa_seq.at(k))) {
	  if (_query.seq.at(k) == lpsa_seq.at(k)) {
	    score += 2;
	  } else {
	    score += 1;
	  }
	} else {
	  if (mask.at(k) > 0) {
	    score = -1;
	  } else {
	    score = 0;
	  }
	  edgeStart = k + 1;
	}
	if (score >= _edge_score_min) {
	  pass++;
	  break;
	}
    }
    score = 0;
    for (int k = querySection_End - 1; k > edgeStart + 5; k--) {
	if (match_seq.at(k) == '+') {
	  score += 1;
	} else if (match_seq.at(k) == toupper(lpsa_seq.at(k))) {
	  if (_query.seq.at(k) == lpsa_seq.at(k)) {
	    score += 2;
	  } else {
	    score += 1;
	  }
	} else {
	  if (mask.at(k) > 0) {
	    score = -1;
	  } else {
	    score = 0;
	  }
	  edgeEnd = k - 1;
	}
	if (score >= _edge_score_min) {
	  pass++;
	  break;
	}
    }

    if (pass == 2) {
	int k = querySection_Start - 1;
	for (; k < edgeStart; k++) {
	  lpsa_seq.at(k) = '.';
	}
	k = edgeEnd + 1;
	for (; k < querySection_End; k++) {
	  lpsa_seq.at(k) = '.';
	}
    }
    // --------------------------------------------- Identity
    int matches = 0;
    int mm = 0;
    int dots = 0;
    for (unsigned i = 0; i < lpsa_seq.size(); i++) {
	if (lpsa_seq.at(i) != '.') {
	  if (_query.seq.at(i) == toupper(lpsa_seq.at(i))) {
	    matches++;
	  } else {
	    mm++;
	  }
	} else {
	  dots++;
	}
    }
    float sec_iden = float(matches) / float(matches + mm);
    if (sec_iden > _sec_iden_min && matches > _sec_match_min) {
	_3_lpsaout << _subject.ac << '\t' << _subject.taxa_id;
	_3_lpsaout << '\t' << matches << "\t" << mm << "\t" << lpsa_seq
		   << endl;
    }
  } // if querySection_Start >= 0
  querySection_Start = -1;
  querySectionSeq.assign("");
	matchSectionSeq.assign("");
	subjectSectionSeq.assign("");
	return;
}

void ProcessInput::_load_querySeq(string inSeq) {
  //*
  // string inSeqFile(inSeq);
  // inSeqFile.append(".fasta");

  string line;
  _fin0.open(inSeq.c_str());
  if (!_fin0.is_open()) {
    cerr << "Error in ProcessInput::_load_querySeq, can't open: " << inSeq << endl;
    exit(-1);
  }
  getline(_fin0, line);
  stringstream ss(line);
  ss >> line;
  _query.head.assign(line);
  _query.seq.assign("");
  getline(_fin0, line);
  while (!_fin0.eof()) {
    if (line.size() > 0) {
	if (line.at(0) != '>') {
	  _query.seq.append(line);
	}
    }
    getline(_fin0, line);
  }
  _fin0.close();
  _query.sz = _query.seq.size();
}

ProcessInput::ProcessInput() {
  _edge_score_min = EDGE_SCORE_MIN_;
  _gap_edg_size = GAP_EDG_SIZE_;
  _sec_match_min = SEC_MATCH_MIN_;
  _sec_iden_min = SEC_IDEN_MIN_;
}

ProcessInput::~ProcessInput() {
  // TODO Auto-generated destructor stub
}

} /* namespace std */
