/*
 * StII.cpp
 *
 *  Created on: Jun 21, 2019
 *      Author: nmalhis
 */

#include "II.h"

namespace std {

II::II() {
	ikey = 0;
	i2 = 0;
}

II::II(const II &ii) {
	ikey = ii.ikey;
	i2 = ii.i2;
}

II::~II() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
