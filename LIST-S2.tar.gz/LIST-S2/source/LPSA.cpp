/*
 * SMSA.cpp
 *
 *  Created on: Jun 21, 2019
 *      Author: nmalhis
 */

#include "LPSA.h"

namespace std {

  LPSA::LPSA() {
    ST_max = 0;
    SI = 0;
    taxa_id = 0;
    ST = 0;
    matches = 0;
    identity = 0;
    mm = 0;
    valid = false;
    sz = 0;
    first = 0;
    last = 0;
  }

  LPSA::LPSA(const LPSA &lpsa) {
    ST_max = lpsa.ST_max;
    SI = lpsa.SI;
    taxa_id = lpsa.taxa_id;
    ST = lpsa.ST;
    matches = lpsa.matches;
    identity = lpsa.identity;
    mm = lpsa.mm;
    valid = lpsa.valid;
    sz = lpsa.sz;
    first = lpsa.first;
    last = lpsa.last;
    ac.assign(lpsa.ac);
    seq.assign(lpsa.seq);
  }

  LPSA::LPSA(const string &line) {
    ST_max = 0;
    seq.assign(""); // loaded next
    ac.assign(""); // loaded next
    valid = false; // loaded later
    ST = 0;        // loaded next
    matches = 0;
    identity = 0;
    mm = 0;
    taxa_id = 0;
    stringstream ss(line);
    ss >> ac;
    ss >> taxa_id;
    ss >> matches;
    ss >> mm;
    ss >> seq;
    for (first = 0; first < seq.size(); first++) {
      if (seq.at(first) != '.')
	break;
    }
    for (last = seq.size() - 1; last >= 0; last--) {
      if (seq.at(last) != '.')
	break;
    }
    sz = matches + mm;
    identity = float(matches) / sz;
    SI = short(identity * 100);
  }

  LPSA::LPSA(const string &line, const short &typ) {
    // ================================= not updated: matches and mm
    ST_max = 0;
    seq.assign("");
    ac.assign("");
    SI = 0;
    valid = false;
    sz = 0;
    ST = 0;
    matches = 0;
    identity = 0;
    mm = 0;
    taxa_id = 0;
    first = 0;
    last = 0;

    stringstream ss(line);
    ss >> ac;
    ss >> seq;
    ss >> matches;
    ss >> mm;
    ss >> seq;
    sz = matches + mm;
    identity = float(matches) / sz;
  }

  void LPSA::set(const LPSA& lpsa) {
    SI = lpsa.SI;
    ST_max = lpsa.ST_max;
    taxa_id = lpsa.taxa_id;
    ST = lpsa.ST;
    matches = lpsa.matches;
    identity = lpsa.identity;
    mm = lpsa.mm;
    valid = lpsa.valid;
    sz = lpsa.sz;
    first = lpsa.first;
    last = lpsa.last;
    ac.assign(lpsa.ac);
    seq.assign(lpsa.seq);
  }

  void LPSA::set(const string& line) {
    valid = false; // loaded later
    stringstream ss(line);
    ss >> ac;
    ss >> taxa_id;
    ss >> matches;
    ss >> mm;
    ss >> seq;
    for (first = 0; first < seq.size(); first++) {
      if (seq.at(first) != '.')
	break;
    }
    for (last = seq.size() - 1; last >= 0; last--) {
      if (seq.at(last) != '.')
	break;
    }
    sz = matches + mm;
    identity = float(matches) / sz;
    SI = short(float(100 * matches) / sz);
  }

  void LPSA::clear() {
    ST_max = 0;
    SI = 0;
    taxa_id = 0;
    ST = 0;
    matches = 0;
    identity = 0;
    mm = 0;
    valid = false;
    sz = 0;
    first = 0;
    last = 0;
    ac.assign("");
    seq.assign("");
  }

  LPSA::~LPSA() {
    // TODO Auto-generated destructor stub
  }

} /* namespace std */
