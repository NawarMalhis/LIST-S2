//============================================================================
// Name        : Process_DB.cpp
// Author      : Nawar Malhis
// Version     :
// Copyright   : Your copyright notice
//============================================================================

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <stdlib.h> /* srand, rand */
#include <vector>
#include <set>
#include <algorithm>
#include <unistd.h> // sleep
#include <math.h> // log
#include <cmath>
#include <time.h>       /* time */

using namespace std;

void process_uniprot(string spFile, string trFile, string out33Path);
void process_taxa(string inFile, string outFile);

int main(int argc, char* argv[]) {
  cerr << "\n Building the alignment database for LIST-S2 from UniProt SwissProt/TrEMBL" << endl;
  cerr << " By Nawar Malhis @msl.UBC.ca (2019)" << endl;
  if (argc == 3) {
    process_taxa("Taxa/tmp_taxa.txt", "Taxa/tID_ptID.txt");
    cerr << "\nProcess DB" << endl;
    process_uniprot(argv[1], argv[2], "DB33");
  } else {
    cerr << "./process_db UniProt/uniprot_sprot.fasta UniProt/uniprot_trembl.fasta " << endl;
  }
  return 0;
}

void process_taxa(string inFile, string outFile) {
  int cnt, cntv;
  int tmpi1, tmpi2;
  string line, tmps;
  vector <int> tVec;
  set <int> virusSet;
  ifstream fin;
  ofstream fout;

  // ----------------- READ
  fin.open(inFile.c_str());
  if(!fin.is_open()) {
    cerr << "Error, can't open: " << inFile << endl;
    exit(1);
  }
  getline(fin, line);
  while(!fin.eof()) {
    stringstream ss(line);
    ss >> tmpi1;
    ss >> tmpi2;
    if (tmpi1 < 4000000) {
      while (tmpi1 >= tVec.size()) {
	tVec.push_back(-1);
      }
      tVec.at(tmpi1) = tmpi2;
    } else {
      cerr << "Large Taxa ID:\t" << line << endl;
    }
    getline(fin, line);
  }
  fin.close();

  // ---------------- PROCESS
  unsigned lastVSsize = virusSet.size();
  virusSet.insert(10239);
  while (lastVSsize < virusSet.size()) {
    // cerr << lastVSsize << "\t" << virusSet.size() << endl;
    lastVSsize = virusSet.size();
    for (unsigned i = 0; i < tVec.size(); i++) {
      if (virusSet.find(tVec.at(i)) != virusSet.end())
	virusSet.insert((int) i);
    }
  }
  // cerr << "tVec.size(): " << tVec.size() << endl;
  for (unsigned i = 0; i < tVec.size(); i++) {
    if (virusSet.find((int) i) != virusSet.end())
      tVec.at(i) = -100;
  }

  // ---------------- SAVE
  cntv = cnt = 0;
  fout.open(outFile.c_str());
  if(!fout.is_open()) {
    cerr << "Error, can't open: " << outFile << endl;
    exit(1);
  }
  for (unsigned i = 0; i < tVec.size(); i++) {
    if (tVec.at(i) != -1) {
      fout << i << "\t" << tVec.at(i) << endl;
      if (tVec.at(i) == -100) {
	cntv++;
      } else {
	cnt++;
      }
    }
  }  
  fout.close();
  // cerr << cnt << "\t" << cntv << endl;
}

void process_uniprot(string spFile, string trFile, string out33Path) {
  ifstream fin;
  int tmpi1, tmpi2;
  string line, tmps;
  vector <int> tVec;
  string mkdir("mkdir ");
  string out33(out33Path);
  if (out33.at(out33.size() - 1) != '/')
    out33.append("/");
  mkdir.append(out33);
  mkdir.append(" 2> tmp/junk");
  int ret1 = system(mkdir.c_str());
  vector<string> inDB;
  vector<string> outDB;
  ofstream oVec[33];
  inDB.push_back(spFile);
  inDB.push_back(trFile);
  for (int i = 0; i < 33; i++) {
    string dr(out33);
    dr.append("DB_");
    stringstream ss;
    ss << i;
    ss >> tmps;
    dr.append(tmps);
    dr.append("/");
    outDB.push_back(dr);
  }

  for (int i = 0; i < 33; i++) {
    string cmd("mkdir ");
    cmd.append(outDB.at(i));
    cmd.append(" 2> tmp/junk");
    // cerr << cmd << endl;
    int ret2 = system(cmd.c_str());
    string dr((outDB.at(i)));
    dr.append("up.fasta");
    oVec[i].open(dr.c_str());
  }

  // ----------------- READ Taxa
  fin.open("Taxa/tID_ptID.txt");
  if(!fin.is_open()) {
    cerr << "Error, can't open: Taxa/tID_ptID.txt" << endl;
    exit(1);
  }
  getline(fin, line);
  while(!fin.eof()) {
    stringstream ss(line);
    ss >> tmpi1;
    ss >> tmpi2;
    if (tmpi1 < 4000000) {
      while (tmpi1 >= tVec.size()) {
	tVec.push_back(-1);
      }
      tVec.at(tmpi1) = tmpi2;
    } else {
      cerr << "Large Taxa ID:\t" << line << endl;
    }
    getline(fin, line);
  }
  fin.close();
  // ----------------------------------
  int i = -1;
  int cnt, cntv;
  cntv = cnt = 0;

  for (unsigned fl = 0; fl < inDB.size(); fl++) {
    ifstream dbin;
    dbin.open(inDB.at(fl).c_str());
    if (!dbin.is_open()) {
      cerr << "Error in process_uniprot, can't open " << inDB.at(fl)
	   << endl;
      exit(1);
    }
    int tid;
    cerr << "Processing " << inDB.at(fl) << ": ";
    getline(dbin, line);
    while (!dbin.eof()) {
      if (line.size() > 0) {
	if (line.at(0) == '>') {
	  if ((cnt+cntv) % 100000 == 0)
	    cerr << '.';
	  i++;
	  i = i % 33;
	  stringstream ss(line);
	  ss >> tmps;
	  oVec[i] << tmps;
	  int p1 = line.find("OX=");
	  int p2 = line.find(' ', p1 + 2);
	  int sz = p2 - p1;
	  stringstream sst(line.substr(p1 + 3, sz - 3));
	  sst >> tid;
	  oVec[i] << " " << tid << endl; // line.substr(p1 + 3, sz - 3)
	  if (tid < tVec.size()) {
	    if (tVec.at(tid) == -100) {
	      cntv++;
	    } else {
	      cnt++;
	    }
	  } else {
	    cerr << "ERROR" << endl;
	  }
	} else {
	  oVec[i] << line << endl;
	}
      }
      getline(dbin, line);
    }
    dbin.close();
    cerr << endl;
  }
  for (int i = 0; i < 33; i++) {
    oVec[i].close();
  }
  cerr << "Count: " << cnt << "\tCount V: " << cntv << endl;

  for (unsigned i = 0; i < outDB.size(); i++) {
    cerr << "Formating database " << outDB.at(i) << endl;
    string cmd("makeblastdb -in ");
    cmd.append(outDB.at(i));
    cmd.append("up.fasta -parse_seqids -dbtype prot -title DB -out ");
    cmd.append(outDB.at(i));
    cmd.append("DB");
    int ret3 = system(cmd.c_str());
  }
}
