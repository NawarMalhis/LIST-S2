/*
 * ProcessInput.h
 *
 *  Created on: Jun 21, 2019
 *      Author: nmalhis
 */

#ifndef PROCESSINPUT_H_
#define PROCESSINPUT_H_

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <stdlib.h> /* srand, rand */
#include <vector>
#include <set>
#include <algorithm>
#include <unistd.h> // sleep
#include <math.h> // log
#include <cmath>
#include <time.h>       /* time */

#include "const.h"
#include "LPSA.h"
#include "STP.h"
#include "TaxonomyTree.h"

namespace std {

class ProcessInput {
	short _gap_edg_size;
	short _edge_score_min;

	short _sec_match_min;
	float _sec_iden_min;

	string querySectionSeq;
	int querySection_Start;
	int querySection_End; // after end

	string matchSectionSeq;

	string subjectSectionSeq;
	int sbjctSection_Start;
	int sbjctSection_End; // after end
	int subject_Size;

	vector<LPSA> lpsaVec;
	vector<STP> stpVec;

	string _lpsa_file;
	string _stp_file;
	ofstream _3_lpsaout;
	ifstream _fin0;
public:
	TaxonomyTree TTree;
	string thrds0;
	string thrds;
	LPSA _query;
	LPSA _subject;
	void align(vector<string> &inSeqV, vector<string> &psaV, int dbCount);
	void psa_to_lpsa(string inSeq, string psaID, string lpsa, int tid, int dbCount);
	void lpsa_to_stp(string inSeq, string outSeq);
	void lpsa_to_stp_O(string inSeq, string outSeq);
	void _process_alignment();
	void _load_querySeq(string inSeq);
	void _new_subject(string &line);
	void _new_section(string &line);
	void _in_section(string &line);
	void _process_section();
	void _load_lpsaVec();
	void _process_lpsaVec();
	void _process_lpsaVec_b();
	void _process_lpsaVec_O();
	int _get_LI(int loci, int pidx);
	int _get_TID(string fasta_file);
	int _get_TID(string psaID, int dbCount);

	void clean();
	ProcessInput();
	virtual ~ProcessInput();

	static short _get_aa_idx(char aa) {
		switch (aa) {
		case 'A':
			return 0;
		case 'R':
			return 1;
		case 'N':
			return 2;
		case 'D':
			return 3;
		case 'C':
			return 4;
		case 'Q':
			return 5;
		case 'E':
			return 6;
		case 'G':
			return 7;
		case 'H':
			return 8;
		case 'I':
			return 9;
		case 'L':
			return 10;
		case 'K':
			return 11;
		case 'M':
			return 12;
		case 'F':
			return 13;
		case 'P':
			return 14;
		case 'S':
			return 15;
		case 'T':
			return 16;
		case 'W':
			return 17;
		case 'Y':
			return 18;
		case 'V':
			return 19;
		}
		return 20;
	}
};

} /* namespace std */

#endif /* PROCESSINPUT_H_ */
