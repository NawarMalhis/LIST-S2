/*
 * const.h
 *
 *  Created on: Jun 21, 2019
 *  Author: nmalhis
 */

#ifndef CONST_H_
#define CONST_H_

#define _ROOT_DATA	"" 
#define _TMP		"tmp/"
#define _LEARNED	"learned_files/"
#define _DB_PATH	"DB/DB_" // "/data/nmalhis/DB33_SPTR/DB_"

#define EDGE_SCORE_MIN_	3
#define GAP_EDG_SIZE_	2
#define	SEC_MATCH_MIN_	20
#define	SEC_IDEN_MIN_ 	0.35

#define	STP_RADIOS	5
#define	STP_MATCH_MIN	20
#define	STP_IDEN_MIN	0.5
#define	_HIGH_DEPTH	100000

#define _RESCALE_BASE	14

#define _PM2_IDEN_MIN	6
#define _PAM__IDEN_MIN	4
#define _MIN_DEPTH	3

#define _L2SIZE	700
#define _DistributionSIZE 10001

#endif /* CONST_H_ */
