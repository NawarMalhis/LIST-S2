/*
 * STP.h
 *
 *  Created on: Jun 21, 2019
 *      Author: nmalhis
 */

#ifndef STP_H_
#define STP_H_

#include <string>
#include <string.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <vector>
#include <set>
#include <algorithm>
#include <unistd.h> // sleep
#include <math.h> // log2

#include "const.h"

namespace std {

class STP {
	void _split_st3(string &st3, short &a_st, short &a_i, int &a_c);
	void _split_st2(string &st2, short &r_i, int &r_c);
public:
	static short ST_max;
	static int Taxa_ID;
	int loci;
	char raa;
	// char msk;
	short ri;
	short ai_max;
	int depth;
	short a_staxa[20];
	short a_lIdentity[20];
	short a_sIdentity[20];
	int a_count[20];
	vector<short> stp_identity;
	vector<int> stp_count;

	static float pam_score[20];

	STP();
	STP(const STP &stp);
	STP(const string &line);

	float compute_PAM_scores();
	float compute_PM2_scores();
	int get_alleles_cover();
	string to_string();

	virtual ~STP();
};

} /* namespace std */

#endif /* STP_H_ */
