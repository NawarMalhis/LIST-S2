/*
 * SMSA.h
 *
 *  Created on: Jun 21, 2019
 *      Author: nmalhis
 */

#ifndef LPSA_H_
#define LPSA_H_

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <stdlib.h> /* srand, rand */
#include <vector>
#include <set>
#include <algorithm>
#include <unistd.h> // sleep
#include <math.h> // log
#include <cmath>
#include <time.h>       /* time */

namespace std {

class LPSA {
public:
	string head;
	string seq;
	string ac;
	int first;
	int last;
	int sz;
	int SI;
	int taxa_id;
	int mm; // mismatches
	short ST;
	short ST_max;
	bool valid;
	int matches;
	float identity;

	LPSA();
	LPSA(const LPSA &lpsa);
	LPSA(const string &line);
	LPSA(const string &line, const short &typ);

	void set(const LPSA &lpsa);
	void set(const string &line);
	void clear();
	virtual ~LPSA();
};

} /* namespace std */

#endif /* LPSA_H_ */
