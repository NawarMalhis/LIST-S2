//============================================================================
// Name        : LIST2A.cpp
// Author      : Nawar Malhis
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "const.h"
#include "Score.h"
#include "ProcessInput.h"

using namespace std;

struct PSEQ {
  string name_fasta;
  string name_psa;
  string name_lpsa;
  string name_stp;
  string name_list;
  string cname;
  int ox;
  PSEQ () {
    ox = 0;
  }

  PSEQ (const PSEQ &ps) {
    name_fasta.assign(ps.name_fasta);
    name_psa.assign(ps.name_psa);
    name_lpsa.assign(ps.name_lpsa);
    name_stp.assign(ps.name_stp);
    name_list.assign(ps.name_list);
    cname.assign(ps.cname);
    ox = ps.ox;
  }

  void set(string name, string dr) {
    if (name.find(".fasta") == name.size() - 6) {
      cname.assign(name.substr(0, name.size() - 6));
    } else {
      cname.assign(name);
    }
    if (dr.at(dr.size() - 1) != '/')
      dr.append("/");

    name_fasta.assign(_ROOT_DATA);
    name_fasta.append(dr);
    name_list.assign(name_fasta);
    
    name_fasta.append(name);
    name_list.append(cname);
    name_list.append(".list");

    name_psa.assign(_ROOT_DATA);
    name_psa.append(_TMP);
    name_psa.append(dr);
    name_psa.append(cname);
    name_lpsa.assign(name_psa);
    name_stp.assign(name_psa);
    
    name_psa.append("_");
    name_lpsa.append(".lpsa");
    name_stp.append(".stp");

    ox = 0;
  }
};
  
void score_server_seq(string seq_file, string stp_file, string list_file);
string mkdrs(string dr, string &flist);

int main(int argc, char *argv[]) {
  int pcount = argc;
  int sCount = 100;
  int thrd = 4;
  cout << "\n LIST-S2 v1.10 (2020)" << endl;
  cout << " Associate to UniProt release 2019_02" << endl;
  cout << " By: Nawar Malhis, PhD" << endl;
  cout << " Michael Smith Laboratories" << endl;
  cout << " UNIVERSITY OF BRITISH COLUMBIA" << endl;
  cout << endl;

  if (pcount == 4) {
    string arg2(argv[2]);
    string arg3(argv[3]);
    stringstream ss2(arg2);
    ss2 >> sCount;
    stringstream ss3(arg3);
    ss3 >> thrd;
    pcount = 2;
    if (sCount < 1) {
      cerr << " Invalid seq counts "; // << argv[2] << endl;
      exit(1);
    }
    if (thrd < 1) {
      cerr << " Invalid thread counts "; // << argv[3] << endl;
      exit(1);
    }
  }
  if (pcount != 2) {
    cout << "format: ./list 'data_path' [#seq  #threads]" << endl;
  } else {
    cout << " Processing up to " << sCount << " sequences in each Database iteration using ";
    cout << thrd << " threads" << endl << endl;
    cout << " Input sequences:" << endl;
    vector <PSEQ> psV;
    vector <vector <PSEQ> > psVV;
    PSEQ ps;
    string flist;
    string cln(mkdrs(argv[1], flist));
    string inPath(argv[1]);
    string line, oname;
    ifstream fin;
    ProcessInput procIn;
    fin.open(flist.c_str());
    getline(fin, line);
    while (!fin.eof()) {
      if (line.find(".fasta") == line.size() - 6) {
	ps.set(line ,inPath);
	ps.ox = procIn._get_TID(ps.name_fasta);
	if (ps.ox >= 0) {
	  psV.push_back(ps);
	  if (ps.ox > 0) {
	    cout << psV.size() << ") " << ps.cname << "\tOX=" << ps.ox << endl;
	  } else {
	    cout << psV.size() << ") " << ps.cname << endl;
	  }
	}
      }
      getline(fin, line);
    }
    fin.close();
    
    string cmd("rm ");
    cmd.append(flist);
    int ret = system(cmd.c_str());
    
    if (psV.size() > 0) {
      stringstream sss;
      sss << thrd;
      sss >> procIn.thrds;
      procIn.thrds.append(" ");
      if (thrd > 1) {
	stringstream ss;
	ss << thrd - 1;
	ss >> procIn.thrds0;
      } else {
	procIn.thrds0.assign("1");
      }
      cout << "\n A total of " << psV.size() << " fasta sequences in " << inPath << endl << endl;
      
      int k = 0;
      psVV.push_back(vector<PSEQ>());
      for (unsigned i = 0; i < psV.size(); i++) {
	if (psVV.at(k).size() >= (unsigned) sCount) {
	  psVV.push_back(vector<PSEQ>());
	  k++;
	}
	psVV.at(k).push_back(psV.at(i));
      }
      cout << " Database sections ..........\t: ";
      for (unsigned k = 0; k < 33; k++) {
	cout << (k + 1) % 10;
      }
      cout << endl;
      cout.flush();
      for (unsigned k = 0; k < psVV.size(); k++) {
	if (sCount > 1) {
	  cout << " Aligning sequences " << k * sCount + 1 << " to ";
	  cout << k * sCount + psVV.at(k).size() << "\t: ";
	} else {
	  cout << " Aligning ";
	  cout << psVV.at(k).at(0).cname << "    \t: ";
	}
	cout.flush();
	// ============================================================================
	vector <string> seqV;
	vector <string> psaV;
	for (unsigned x = 0; x < psVV.at(k).size(); x++) {
	  seqV.push_back(psVV.at(k).at(x).name_fasta);
	  psaV.push_back(psVV.at(k).at(x).name_psa);
	}
	procIn.align(seqV, psaV, 33);
	cout << endl << endl;;
	for (unsigned i = 0; i < psVV.at(k).size(); i++) {
	  procIn.clean();
	  if (psVV.at(k).at(i).ox == 0) {
	    psVV.at(k).at(i).ox =
	      procIn._get_TID(psVV.at(k).at(i).name_psa, 33);
	  }
	  if (procIn.TTree.taxaVec.at(psVV.at(k).at(i).ox) > 0) {
	    procIn.psa_to_lpsa(psVV.at(k).at(i).name_fasta, psVV.at(k).at(i).name_psa,
			       psVV.at(k).at(i).name_lpsa, psVV.at(k).at(i).ox, 33);
	    procIn.lpsa_to_stp(psVV.at(k).at(i).name_lpsa, psVV.at(k).at(i).name_stp);
	    cout << i+1 << ") " << psVV.at(k).at(i).cname << "\tOX=";
	    cout << psVV.at(k).at(i).ox << " \tlineage size: " << STP::ST_max << endl;
	    score_server_seq(psVV.at(k).at(i).name_fasta, psVV.at(k).at(i).name_stp,
			     psVV.at(k).at(i).name_list);
	  } else {
	    cout << i+1 << ") " << psVV.at(k).at(i).cname << "  X\tOX=";
	    cout << psVV.at(k).at(i).ox << "\tRemoved, "<< psVV.at(k).at(i).ox;
	    cout << " is a virus OX" << endl;
	  }
	  cout.flush();
	}
	ret = system(cln.c_str());
      }
      string cmd("rmdir ");
      cmd.append(_ROOT_DATA);
      cmd.append(_TMP);
      cmd.append(inPath);
      ret = system(cmd.c_str());
    }
  }
  cerr << endl;
  return 0;
}

string mkdrs(string dr, string &flist) {
    string tmp_path(_ROOT_DATA);
    tmp_path.append(_TMP);
    string junk(tmp_path);
    junk.append("junk");
    if (dr.at(dr.size() - 1) != '/')
      dr.append("/");
    string in_path(_ROOT_DATA);
    in_path.append(dr);
    string tmpd_path(tmp_path);
    tmpd_path.append(dr);
    string rmd("rmdir ");
    rmd.append(tmpd_path);
    rmd.append(" 2> ");
    rmd.append(junk);
    string cmd("mkdir ");
    cmd.append(tmpd_path);
    cmd.append(" 2> ");
    cmd.append(junk);
    int ret = system(cmd.c_str());
    
    flist.assign(tmpd_path);
    flist.append("__LIST_dir.tmp");
    cmd.assign("ls ");
    cmd.append(_ROOT_DATA);
    cmd.append(dr);
    cmd.append(" > ");
    cmd.append(flist);
    ret = system(cmd.c_str());

    string cln("rm ");
    cln.append(tmp_path);
    cln.append(dr);
    cln.append("*");
    return cln;
}

void score_server_seq(string seq_file, string stp_file, string list_file) {
  Score s;
  s.load__norm("norm_1_mn_mx.txt", "norm_2_mn_mx.txt", "cover_tr.txt");
  s._process_seq(seq_file, stp_file, list_file);
}

